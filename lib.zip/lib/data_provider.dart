/* import 'package:flutter/material.dart';

class DataProvider extends ChangeNotifier {
  List<Map<String, dynamic>> encargos = [];

  void agregarEncargo(Map<String, dynamic> nuevoEncargo) {
    encargos.add(nuevoEncargo);
    notifyListeners();
  }

  List<Map<String, dynamic>> getEncargos() {
    return encargos;
  }
}
 */