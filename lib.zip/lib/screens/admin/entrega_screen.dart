import 'package:flutter/material.dart';

class EntregaScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Aquí irá la lista de pedidos entregados"),
    );
  }
}
