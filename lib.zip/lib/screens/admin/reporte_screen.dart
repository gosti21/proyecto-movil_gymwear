import 'package:flutter/material.dart';

class ReporteScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Aquí irá la lista de reportes"),
    );
  }
}
